"""
Configuration for AprilTag robot localization.

Change only these values for normal use.
"""

# Printed AprilTag size. Must match the real physical marker size.
MARKER_SIZE_METERS = 0.097

# Must match the printed AprilTag family.
# Options: 16h5, 25h9, 36h10, 36h11
TAG_FAMILY = "16h5"

# Use None to accept all tag IDs.
# Use an integer like 0 to only track one marker.
TARGET_TAG_ID = None

# Camera index on Linux usually starts from 0.
CAMERA_INDEX = 0

# Keep these as None if you want the camera default.
# Best practice: use the same resolution as calibration.
FRAME_WIDTH = None
FRAME_HEIGHT = None

# Robot/docking thresholds.
CENTER_TOLERANCE_M = 0.05
STOP_DISTANCE_M = 0.35
YAW_TOLERANCE_DEG = 7.0

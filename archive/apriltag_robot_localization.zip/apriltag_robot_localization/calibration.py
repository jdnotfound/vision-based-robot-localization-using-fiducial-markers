import numpy as np


def load_calibration(path: str):
    """
    Load camera calibration from calibration_data.npz.

    Expected keys:
    - mtx  : camera matrix
    - dist : distortion coefficients
    """
    try:
        with np.load(path) as data:
            if "mtx" not in data or "dist" not in data:
                raise RuntimeError(
                    f"{path} must contain keys 'mtx' and 'dist'"
                )

            cam_matrix = data["mtx"]
            dist_coeffs = data["dist"]

    except FileNotFoundError:
        raise RuntimeError(
            f"Calibration file not found: {path}. "
            "Copy calibration_data.npz into this folder first."
        )

    if cam_matrix.shape != (3, 3):
        raise RuntimeError(
            f"Invalid camera matrix shape: {cam_matrix.shape}. Expected (3, 3)."
        )

    return cam_matrix, dist_coeffs

from collections import deque


class MovingAveragePoseFilter:
    """
    Small moving average filter for stable robot commands.

    This is optional. Keep window_size small because too much smoothing
    creates delay in robot movement.
    """

    def __init__(self, window_size=5):
        self.window_size = int(window_size)
        self.history = deque(maxlen=self.window_size)

    def update(self, pose):
        if pose is None:
            self.history.clear()
            return None

        self.history.append(pose)

        numeric_keys = [
            "tag_x_m",
            "tag_y_m",
            "tag_z_m",
            "distance_m",
            "cam_x_m",
            "cam_y_m",
            "cam_z_m",
            "yaw_deg",
        ]

        filtered = dict(pose)

        for key in numeric_keys:
            values = [p[key] for p in self.history if key in p]
            if values:
                filtered[key] = sum(values) / len(values)

        return filtered

from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from robot_logic import decide_robot_command


test_poses = [
    None,
    {"tag_x_m": 0.10, "tag_z_m": 1.0, "yaw_deg": 0.0},
    {"tag_x_m": -0.10, "tag_z_m": 1.0, "yaw_deg": 0.0},
    {"tag_x_m": 0.00, "tag_z_m": 1.0, "yaw_deg": 12.0},
    {"tag_x_m": 0.00, "tag_z_m": 1.0, "yaw_deg": -12.0},
    {"tag_x_m": 0.00, "tag_z_m": 0.30, "yaw_deg": 0.0},
    {"tag_x_m": 0.00, "tag_z_m": 1.0, "yaw_deg": 0.0},
]

for pose in test_poses:
    print("pose:", pose)
    print("command:", decide_robot_command(pose))
    print()

import cv2


def main():
    print("OpenCV version:", cv2.__version__)

    if not hasattr(cv2, "aruco"):
        print("ERROR: cv2.aruco not found.")
        print("Install opencv-contrib-python, not plain opencv-python.")
        return

    print("cv2.aruco available: YES")

    required = [
        "DICT_APRILTAG_16h5",
        "DICT_APRILTAG_25h9",
        "DICT_APRILTAG_36h10",
        "DICT_APRILTAG_36h11",
        "ArucoDetector",
        "DetectorParameters",
    ]

    for name in required:
        print(f"{name}:", "YES" if hasattr(cv2.aruco, name) else "NO")


if __name__ == "__main__":
    main()

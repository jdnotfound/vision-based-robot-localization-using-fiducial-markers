import cv2
import numpy as np


APRILTAG_DICTS = {
    "16h5": cv2.aruco.DICT_APRILTAG_16h5,
    "25h9": cv2.aruco.DICT_APRILTAG_25h9,
    "36h10": cv2.aruco.DICT_APRILTAG_36h10,
    "36h11": cv2.aruco.DICT_APRILTAG_36h11,
}


class AprilTagPoseEstimator:
    """
    Detects AprilTags using OpenCV ArUco AprilTag dictionaries
    and estimates 6-DoF pose using solvePnP.

    Coordinate notes:
    - tvec is marker position relative to camera.
    - OpenCV camera coordinates:
        X = right
        Y = down
        Z = forward
    - tag_z_m is the main forward distance value.
    """

    def __init__(self, tag_family, marker_size_m, cam_matrix, dist_coeffs):
        if not hasattr(cv2, "aruco"):
            raise RuntimeError(
                "cv2.aruco not found. Install opencv-contrib-python, not plain opencv-python."
            )

        if tag_family not in APRILTAG_DICTS:
            raise RuntimeError(
                f"Unsupported tag family '{tag_family}'. "
                f"Use one of: {', '.join(APRILTAG_DICTS.keys())}"
            )

        self.tag_family = tag_family
        self.marker_size_m = float(marker_size_m)
        self.cam_matrix = cam_matrix
        self.dist_coeffs = dist_coeffs

        dictionary = cv2.aruco.getPredefinedDictionary(APRILTAG_DICTS[tag_family])
        params = cv2.aruco.DetectorParameters()
        self.detector = cv2.aruco.ArucoDetector(dictionary, params)

        self.marker_3d_points = self._make_marker_3d_points(self.marker_size_m)

    @staticmethod
    def _make_marker_3d_points(marker_size_m):
        half = marker_size_m / 2.0

        # Same corner order as OpenCV detected corners:
        # top-left, top-right, bottom-right, bottom-left
        return np.array(
            [
                [-half,  half, 0.0],
                [ half,  half, 0.0],
                [ half, -half, 0.0],
                [-half, -half, 0.0],
            ],
            dtype=np.float32,
        )

    def detect_and_estimate(self, frame, target_tag_id=None):
        """
        Returns a list of pose dictionaries.
        """
        corners, ids, rejected = self.detector.detectMarkers(frame)

        if ids is None:
            return [], corners, ids, rejected

        results = []

        for i in range(len(ids)):
            marker_id = int(ids[i][0])

            if target_tag_id is not None and marker_id != int(target_tag_id):
                continue

            marker_2d = corners[i][0].astype(np.float32)

            success, rvec, tvec = cv2.solvePnP(
                self.marker_3d_points,
                marker_2d,
                self.cam_matrix,
                self.dist_coeffs,
                flags=cv2.SOLVEPNP_ITERATIVE,
            )

            if not success:
                continue

            pose = self._build_pose_result(marker_id, rvec, tvec)
            results.append(pose)

        return results, corners, ids, rejected

    def _build_pose_result(self, marker_id, rvec, tvec):
        R, _ = cv2.Rodrigues(rvec)

        tag_x_m = float(tvec[0][0])
        tag_y_m = float(tvec[1][0])
        tag_z_m = float(tvec[2][0])
        distance_m = float(np.linalg.norm(tvec))

        # Camera position in marker/tag coordinate frame.
        camera_pos = -R.T @ tvec

        cam_x_m = float(camera_pos[0][0])
        cam_y_m = float(camera_pos[1][0])
        cam_z_m = float(camera_pos[2][0])

        # Approximate yaw of camera relative to tag.
        R_cam = R.T
        yaw_rad = np.arctan2(R_cam[0, 2], R_cam[2, 2])
        yaw_deg = float(np.degrees(yaw_rad) + 180.0)

        if yaw_deg > 180.0:
            yaw_deg -= 360.0

        return {
            "detected": True,
            "id": marker_id,

            # Marker position relative to camera.
            "tag_x_m": tag_x_m,
            "tag_y_m": tag_y_m,
            "tag_z_m": tag_z_m,
            "distance_m": distance_m,

            # Camera position relative to marker.
            "cam_x_m": cam_x_m,
            "cam_y_m": cam_y_m,
            "cam_z_m": cam_z_m,

            "yaw_deg": yaw_deg,

            # Keep these for drawing/debug only.
            "rvec": rvec,
            "tvec": tvec,
        }

    def draw_debug(self, frame, corners, ids, pose_results):
        """
        Draw markers and axes for laptop testing.
        Do not use this in board/headless mode.
        """
        if ids is not None:
            cv2.aruco.drawDetectedMarkers(frame, corners, ids)

        for pose in pose_results:
            cv2.drawFrameAxes(
                frame,
                self.cam_matrix,
                self.dist_coeffs,
                pose["rvec"],
                pose["tvec"],
                self.marker_size_m * 0.5,
            )

            text = (
                f"ID:{pose['id']} "
                f"Z:{pose['tag_z_m']:.2f}m "
                f"X:{pose['tag_x_m']:.2f}m "
                f"Yaw:{pose['yaw_deg']:.1f}"
            )

            cv2.putText(
                frame,
                text,
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 255),
                2,
            )

        return frame


def strip_debug_fields(pose):
    """
    Remove numpy-heavy fields before JSON/CSV output.
    """
    cleaned = {}

    for key, value in pose.items():
        if key in ("rvec", "tvec"):
            continue

        if isinstance(value, float):
            cleaned[key] = round(value, 5)
        else:
            cleaned[key] = value

    return cleaned

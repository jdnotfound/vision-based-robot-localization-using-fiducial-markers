# AprilTag Robot Localization Runtime

This is the board-ready AprilTag localization code for the STM32MP25 integration phase.

The code is designed to work in two modes:

1. Laptop test mode with display
2. Embedded/headless mode on the ST Linux board

## Final selected marker

AprilTag is the selected marker.

Make sure `TAG_FAMILY` matches the printed marker:

- `16h5`
- `25h9`
- `36h10`
- `36h11`

Current default:

```python
TAG_FAMILY = "16h5"
MARKER_SIZE_METERS = 0.097
```

Change this in `config.py` or pass it from command line.

## Files

```text
main.py                  Main runtime loop
config.py                Main settings
calibration.py           Loads calibration_data.npz
camera_source.py         Opens webcam or video file
apriltag_pose.py         AprilTag detection + solvePnP pose estimation
pose_filter.py           Optional moving average filter
robot_logic.py           Converts pose into simple robot commands
csv_logger.py            Optional CSV logging
tools/check_opencv.py    Checks OpenCV AprilTag support
tools/test_robot_logic.py Tests command logic without camera
services/                systemd service for embedded auto-start
```

## Install on laptop

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Check OpenCV

```bash
python3 tools/check_opencv.py
```

You must see:

```text
cv2.aruco available: YES
DICT_APRILTAG_16h5: YES
ArucoDetector: YES
```

## Required calibration file

Copy your existing file here:

```text
calibration_data.npz
```

It must contain:

```text
mtx
dist
```

## Run with webcam and display

```bash
python3 main.py --tag-family 16h5 --display
```

For 36h11:

```bash
python3 main.py --tag-family 36h11 --display
```

## Run headless

This is the mode for STM32MP25 later:

```bash
python3 main.py --tag-family 16h5 --json
```

Example output:

```json
{
  "detected": true,
  "id": 0,
  "tag_x_m": 0.0123,
  "tag_y_m": -0.004,
  "tag_z_m": 0.815,
  "distance_m": 0.816,
  "yaw_deg": -2.4,
  "robot_command": "FORWARD"
}
```

## Log CSV

```bash
python3 main.py --tag-family 16h5 --csv run_log.csv
```

## Test from video file

Useful when board hardware is not available:

```bash
python3 main.py --video sample.mp4 --tag-family 16h5 --display
```

## Test robot command logic without camera

```bash
python3 tools/test_robot_logic.py
```

## Pose values

Most useful values:

```text
tag_x_m       left/right marker offset from camera
tag_z_m       forward distance from camera to marker
distance_m    straight-line distance
yaw_deg       camera angle relative to marker
```

Robot command logic:

```text
No tag        SEARCH
Too close     STOP
Tag right     TURN_RIGHT
Tag left      TURN_LEFT
Yaw error     ROTATE_LEFT / ROTATE_RIGHT
Centered      FORWARD
```

## systemd service for board

Copy folder to the board:

```bash
/home/root/apriltag_robot_localization
```

Install service:

```bash
cp services/apriltag_localization.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable apriltag_localization.service
systemctl start apriltag_localization.service
```

Check logs:

```bash
journalctl -u apriltag_localization.service -f
```

## Notes for STM32MP25

On the board, avoid display mode first.

Use:

```bash
python3 main.py --json
```

Not:

```bash
python3 main.py --display
```

Display mode requires GUI support and is mainly for laptop testing.

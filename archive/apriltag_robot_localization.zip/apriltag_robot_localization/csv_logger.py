import csv
from pathlib import Path


DEFAULT_FIELDNAMES = [
    "timestamp",
    "frame",
    "detected",
    "id",
    "tag_x_m",
    "tag_y_m",
    "tag_z_m",
    "distance_m",
    "cam_x_m",
    "cam_y_m",
    "cam_z_m",
    "yaw_deg",
    "fps",
    "robot_command",
    "robot_reason",
    "linear",
    "angular",
    "reason",
]


class CsvLogger:
    """
    CSV logger that works even when early frames have no detected tag.

    Missing values are written as empty cells.
    Extra fields are ignored.
    """

    def __init__(self, path, fieldnames=None):
        self.path = Path(path)
        self.fieldnames = fieldnames or DEFAULT_FIELDNAMES
        self.file = self.path.open("w", newline="")
        self.writer = csv.DictWriter(
            self.file,
            fieldnames=self.fieldnames,
            extrasaction="ignore",
        )
        self.writer.writeheader()

    def write(self, row):
        clean_row = {key: row.get(key, "") for key in self.fieldnames}
        self.writer.writerow(clean_row)
        self.file.flush()

    def close(self):
        self.file.close()

import argparse
import json
import time

import cv2

from calibration import load_calibration
from camera_source import open_camera_source, read_frame_with_retry
from apriltag_pose import AprilTagPoseEstimator, strip_debug_fields
from pose_filter import MovingAveragePoseFilter
from robot_logic import decide_robot_command
from csv_logger import CsvLogger

import config


def parse_args():
    parser = argparse.ArgumentParser(
        description="AprilTag robot localization runtime"
    )

    parser.add_argument("--camera", type=int, default=config.CAMERA_INDEX)
    parser.add_argument("--video", default=None, help="Optional video file for testing")
    parser.add_argument("--calibration", default="calibration_data.npz")
    parser.add_argument("--tag-family", default=config.TAG_FAMILY)
    parser.add_argument("--marker-size", type=float, default=config.MARKER_SIZE_METERS)
    parser.add_argument("--target-id", type=int, default=config.TARGET_TAG_ID)

    parser.add_argument("--width", type=int, default=config.FRAME_WIDTH)
    parser.add_argument("--height", type=int, default=config.FRAME_HEIGHT)

    parser.add_argument("--display", action="store_true")
    parser.add_argument("--json", action="store_true", help="Print JSON output")
    parser.add_argument("--csv", default=None, help="Optional CSV log path")

    parser.add_argument("--filter-window", type=int, default=5)
    parser.add_argument("--no-filter", action="store_true")

    parser.add_argument(
        "--print-every",
        type=int,
        default=1,
        help="Print every N frames to reduce console spam",
    )

    return parser.parse_args()


def main():
    args = parse_args()

    cam_matrix, dist_coeffs = load_calibration(args.calibration)

    estimator = AprilTagPoseEstimator(
        tag_family=args.tag_family,
        marker_size_m=args.marker_size,
        cam_matrix=cam_matrix,
        dist_coeffs=dist_coeffs,
    )

    cap = open_camera_source(
        camera_index=args.camera,
        video_path=args.video,
        width=args.width,
        height=args.height,
    )

    pose_filter = None if args.no_filter else MovingAveragePoseFilter(args.filter_window)
    csv_logger = CsvLogger(args.csv) if args.csv else None

    frame_count = 0
    prev_time = time.time()

    print(
        f"Started AprilTag localization | family={args.tag_family} | "
        f"marker_size={args.marker_size}m | target_id={args.target_id}",
        flush=True,
    )

    try:
        while True:
            frame = read_frame_with_retry(cap)

            if frame is None:
                output = {
                    "detected": False,
                    "reason": "frame_read_failed",
                    "timestamp": round(time.time(), 3),
                }
                print(json.dumps(output), flush=True)
                continue

            frame_count += 1

            now = time.time()
            fps = 1.0 / max(now - prev_time, 1e-9)
            prev_time = now

            poses, corners, ids, rejected = estimator.detect_and_estimate(
                frame,
                target_tag_id=args.target_id,
            )

            # For robot navigation, use first valid detected marker.
            raw_pose = poses[0] if poses else None

            if pose_filter:
                filtered_pose = pose_filter.update(raw_pose)
            else:
                filtered_pose = raw_pose

            command = decide_robot_command(
                filtered_pose,
                center_tolerance_m=config.CENTER_TOLERANCE_M,
                stop_distance_m=config.STOP_DISTANCE_M,
                yaw_tolerance_deg=config.YAW_TOLERANCE_DEG,
            )

            if filtered_pose is not None:
                output = strip_debug_fields(filtered_pose)
                output["detected"] = True
            else:
                output = {
                    "detected": False,
                }

            output["fps"] = round(fps, 2)
            output["frame"] = frame_count
            output["timestamp"] = round(now, 3)
            output["robot_command"] = command["command"]
            output["robot_reason"] = command["reason"]
            output["linear"] = command["linear"]
            output["angular"] = command["angular"]

            should_print = frame_count % max(args.print_every, 1) == 0

            if should_print:
                if args.json:
                    print(json.dumps(output), flush=True)
                else:
                    if output["detected"]:
                        print(
                            f"ID={output['id']} "
                            f"X={output['tag_x_m']:.3f}m "
                            f"Z={output['tag_z_m']:.3f}m "
                            f"D={output['distance_m']:.3f}m "
                            f"Yaw={output['yaw_deg']:.1f}deg "
                            f"FPS={output['fps']:.1f} "
                            f"CMD={output['robot_command']}",
                            flush=True,
                        )
                    else:
                        print(
                            f"No tag | FPS={output['fps']:.1f} "
                            f"CMD={output['robot_command']}",
                            flush=True,
                        )

            if csv_logger:
                csv_logger.write(output)

            if args.display:
                debug_frame = estimator.draw_debug(frame, corners, ids, poses)

                cv2.putText(
                    debug_frame,
                    f"CMD: {command['command']}",
                    (20, 80),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (0, 255, 0),
                    2,
                )

                cv2.imshow("AprilTag Robot Localization", debug_frame)

                if cv2.waitKey(1) == 27:
                    break

            # For video-file testing, stop cleanly at end of video.
            if args.video:
                current_pos = int(cap.get(cv2.CAP_PROP_POS_FRAMES))
                total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                if total_frames > 0 and current_pos >= total_frames:
                    break

    except KeyboardInterrupt:
        print("Stopped by user", flush=True)

    finally:
        cap.release()

        if args.display:
            cv2.destroyAllWindows()

        if csv_logger:
            csv_logger.close()


if __name__ == "__main__":
    main()

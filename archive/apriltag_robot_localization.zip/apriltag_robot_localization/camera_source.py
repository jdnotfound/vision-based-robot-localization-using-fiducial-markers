import time
import cv2


def open_camera_source(camera_index=0, video_path=None, width=None, height=None):
    """
    Opens either:
    - live camera using /dev/video* through V4L2
    - video file for laptop testing

    video_path is useful while hardware is not available.
    """
    if video_path:
        cap = cv2.VideoCapture(video_path)
        source_name = video_path
    else:
        cap = cv2.VideoCapture(camera_index, cv2.CAP_V4L2)
        source_name = f"camera index {camera_index}"

    if width is not None:
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(width))

    if height is not None:
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(height))

    if not cap.isOpened():
        raise RuntimeError(f"Could not open {source_name}")

    return cap


def read_frame_with_retry(cap, retry_delay_s=0.1):
    """
    Read a frame. If the camera temporarily fails, return None instead of crashing.
    """
    ret, frame = cap.read()

    if not ret:
        time.sleep(retry_delay_s)
        return None

    return frame

def decide_robot_command(
    pose,
    center_tolerance_m=0.05,
    stop_distance_m=0.35,
    yaw_tolerance_deg=7.0,
):
    """
    Converts AprilTag pose into a simple robot command.

    This does not directly drive motors.
    Later, this command can be sent to the motor-control board.

    Main values:
    - tag_x_m: left/right offset from camera center
    - tag_z_m: forward distance
    - yaw_deg: angular misalignment
    """
    if pose is None:
        return {
            "command": "SEARCH",
            "reason": "no_tag_detected",
            "linear": 0.0,
            "angular": 0.25,
        }

    x = pose["tag_x_m"]
    z = pose["tag_z_m"]
    yaw = pose["yaw_deg"]

    if z <= stop_distance_m:
        return {
            "command": "STOP",
            "reason": "target_distance_reached",
            "linear": 0.0,
            "angular": 0.0,
        }

    if abs(x) > center_tolerance_m:
        if x > 0:
            return {
                "command": "TURN_RIGHT",
                "reason": "tag_is_right_of_camera_center",
                "linear": 0.0,
                "angular": -0.20,
            }

        return {
            "command": "TURN_LEFT",
            "reason": "tag_is_left_of_camera_center",
            "linear": 0.0,
            "angular": 0.20,
        }

    if abs(yaw) > yaw_tolerance_deg:
        if yaw > 0:
            return {
                "command": "ROTATE_RIGHT",
                "reason": "positive_yaw_error",
                "linear": 0.0,
                "angular": -0.15,
            }

        return {
            "command": "ROTATE_LEFT",
            "reason": "negative_yaw_error",
            "linear": 0.0,
            "angular": 0.15,
        }

    return {
        "command": "FORWARD",
        "reason": "tag_centered_and_far",
        "linear": 0.15,
        "angular": 0.0,
    }

/*
 * This file is part of the JuMarker library
 * Copyright (c) 2022 David Jurado Rodríguez, Rafael Muñoz Salinas,
 *                    Sergio Garrido Jurado, Rafael Medina Carnicer.
 *
 * JuMarker is published and distributed under the CC BY-NC-SA license.
 * JuMarker is distributed in the hope that it will be useful for
 * non-commercial academic research, but WITHOUT ANY WARRANTY.
 *
 * You should have received a copy of the CC BY-NC-SA license along with
 * this program; if not, write to rmsalinas@uco.es.
 */

#ifndef UCOSLAM_CVVERSIONING_H
#define UCOSLAM_CVVERSIONING_H
#include <opencv2/core/core.hpp>
#if CV_MAJOR_VERSION >= 4
#include <opencv2/imgproc.hpp>
#define CV_P3P cv::SOLVEPNP_P3P
#define CV_REDUCE_SUM cv::REDUCE_SUM
#define CV_FOURCC cv::VideoWriter::fourcc
#define CV_LOAD_IMAGE_COLOR cv::IMREAD_COLOR
#define CV_LOAD_IMAGE_GRAYSCALE cv::IMREAD_GRAYSCALE
#define CV_CAP_PROP_BUFFERSIZE cv::CAP_PROP_BUFFERSIZE
#define CV_INTER_LINEAR cv::INTER_LINEAR
#define CV_RGB2BGR cv::COLOR_RGB2BGR
#define CV_CAP_PROP_EXPOSUREPROGRAM cv::CAP_PROP_EXPOSUREPROGRAM
#define CV_CAP_PROP_RECTIFICATION cv::CAP_PROP_RECTIFICATION
#define CV_CAP_PROP_HUE cv::CAP_PROP_HUE
#define CV_BGR2GRAY cv::COLOR_BGR2GRAY
#define CV_GRAY2BGR cv::COLOR_GRAY2BGR
#define CV_FONT_HERSHEY_COMPLEX cv::FONT_HERSHEY_COMPLEX
#define CV_INTER_NN cv::INTER_LINEAR
#define CV_CAP_PROP_EXPOSURE cv::CAP_PROP_EXPOSURE
#define CV_CAP_PROP_PAN cv::CAP_PROP_PAN
#define CV_CAP_PROP_TILT cv::CAP_PROP_TILT
#define CV_CAP_PROP_ZOOM cv::CAP_PROP_ZOOM
#define CV_CAP_PROP_SETTINGS cv::CAP_PROP_SETTINGS
#define CV_CAP_PROP_FRAME_WIDTH cv::CAP_PROP_FRAME_WIDTH
#define CV_CAP_PROP_FRAME_HEIGHT cv::CAP_PROP_FRAME_HEIGHT
#define CV_CAP_PROP_FRAME_COUNT cv::CAP_PROP_FRAME_COUNT
#define CV_CAP_PROP_FPS cv::CAP_PROP_FPS
#define CV_CAP_PROP_POS_FRAMES cv::CAP_PROP_POS_FRAMES
#define CV_CAP_PROP_FORMAT cv::CAP_PROP_FORMAT
#define CV_CAP_PROP_FOURCC cv::CAP_PROP_FOURCC
#define CV_CAP_PROP_MODE cv::CAP_PROP_MODE
#define CV_CAP_PROP_BRIGHTNESS cv::CAP_PROP_BRIGHTNESS
#define CV_CAP_PROP_CONTRAST cv::CAP_PROP_CONTRAST
#define CV_CAP_PROP_SATURATION cv::CAP_PROP_SATURATION
#define CV_CAP_PROP_GAIN cv::CAP_PROP_GAIN
#define CV_CAP_PROP_CONVERT_RGB cv::CAP_PROP_CONVERT_RGB
#define CV_CAP_PROP_WHITE_BALANCE_BLUE_U cv::CAP_PROP_WHITE_BALANCE_BLUE_U
#define CV_CAP_PROP_WHITE_BALANCE_RED_V cv::CAP_PROP_WHITE_BALANCE_RED_V
#endif

#endif // CVVERSIONING_H
